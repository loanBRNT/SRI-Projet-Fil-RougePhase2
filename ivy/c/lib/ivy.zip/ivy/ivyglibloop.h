/*
*	Ivy, C interface
*
*	Copyright (C) 1997-2000
*	Centre d'�tudes de la Navigation A�rienne
*
* 	Main loop based on the GTK Toolkit
*
*	Authors: Fran�ois-R�gis Colin <fcolin@cena.fr>
*
*	$Id: ivyglibloop.h 1231 2006-04-21 16:34:15Z fcolin $
* 
*	Please refer to file version.h for the
*	copyright notice regarding this software
*/

#ifndef IVYGLIBLOOP_H
#define IVYGLIBLOOP_H

#ifdef __cplusplus
extern "C" {
#endif

/* Nothnig special */
#ifdef __cplusplus
}
#endif

#endif /* IVYGLIBLOOP_H */
